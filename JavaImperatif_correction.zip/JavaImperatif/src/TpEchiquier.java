import java.util.Scanner;

public class TpEchiquier {

	private static final int CHESSBOARD_SIDE_LENGTH = 8;
	private static final int INITIAL_X = 0;
	private static final int INITIAL_Y = 1;

	private static final Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		boolean chessboard[][] = new boolean[CHESSBOARD_SIDE_LENGTH][CHESSBOARD_SIDE_LENGTH];
		int x = INITIAL_X, y = INITIAL_Y;
		
		chessboard[x][y] = true;
		
		do {
			displayChessboard(chessboard);
			
			int[] newPosition = askNewPosition();
			
			if (validateMoveKnight(x, y, newPosition[0], newPosition[1])) {
				chessboard[x][y] = false;
				x = newPosition[0];
				y = newPosition[1];
				chessboard[x][y] = true;
				
				System.out.println("Le cavalier a été déplacé en position (" + x + "," + y + ").");
			} else {
				System.out.println("Déplacement impossible.");
			}
			
		} while (askContinue());
		
		
	}
	
	/**
	 * Finds the index corresponding to a given column name.
	 * @param columnName The name of the column (A-H).
	 * @return The corresponding index (0-7).
	 */
	private static int findIndexFromColumnName(char columnName) {
		return columnName <= (int) 'a' ? columnName - (int) 'A' : columnName - (int) 'a';
	}
	
	/**
	 * Displays a chessboard in the console.
	 * @param chessboard The chessboard to be displayed.
	 */
	private static void displayChessboard(boolean chessboard[][]) {
		System.out.println("  | A | B | C | D | E | F | G | H |");
		for (int line = 0; line < chessboard.length; line++) {
			System.out.print((CHESSBOARD_SIDE_LENGTH - line) + " |");
			for (int column = 0; column < chessboard[line].length; column++) {
				System.out.print(" " + (chessboard[7 - line][column] ? "X" : " ") + " |");
			}
			System.out.println("");
		}
	}
	
	/**
	 * Asks the user whether he wants to continue playing or not.
	 * @return Returns true if the user wants to continue, false otherwise.
	 */
	private static boolean askContinue() {
		String input = "";
		while (!input.equals("Oui") && !input.equals("Non")) {
			System.out.println("Voulez-vous de nouveau essayer de déplacer votre cavalier ? (Oui/Non)");
			input = sc.nextLine();
		}
		
		return input.equals("Oui");
	}
	
	private static int[] askNewPosition() {
		int[] newPosition = new int[2];
		
		String input = "";
		while (!input.matches("^[A-H]{1}[1-" + CHESSBOARD_SIDE_LENGTH + "]{1}$")) {
			System.out.println("Vers quelle case voulez-vous déplacer votre cavalier ? (ex : C3, F8, ...)");
			input = sc.nextLine();
		}
		
		newPosition[0] = Integer.parseInt(input.substring(1,2)) - 1;
		newPosition[1] = findIndexFromColumnName(input.charAt(0));
		
		return newPosition;
	}
	
	private static boolean validateMoveKnight(int positionX, int positionY, int newPositionX, int newPositionY) {
		int movementX = Math.abs(newPositionX - positionX);
		int movementY = Math.abs(newPositionY - positionY);
		
		return isPositionInsideGrid(newPositionX, newPositionY)
				&& (movementX == 2 && movementY == 1 || movementX == 1 && movementY == 2);
	}
	
	private static boolean validateMoveFool(int positionX, int positionY, int newPositionX, int newPositionY) {
		int movementX = Math.abs(newPositionX - positionX);
		int movementY = Math.abs(newPositionY - positionY);
		
		return isPositionInsideGrid(newPositionX, newPositionY)
				&& (movementX > 0 && movementX == movementY);
	}
	
	private static boolean validateMoveTower(int positionX, int positionY, int newPositionX, int newPositionY) {
		int movementX = Math.abs(newPositionX - positionX);
		int movementY = Math.abs(newPositionY - positionY);
		
		return isPositionInsideGrid(newPositionX, newPositionY)
				&& (movementX > 0 ^ movementY > 0);
	}

	private static boolean isPositionInsideGrid(int positionX, int positionY) {
		return positionX >= 0 && positionX < CHESSBOARD_SIDE_LENGTH && positionY >= 0 && positionY < CHESSBOARD_SIDE_LENGTH;
	}

}
