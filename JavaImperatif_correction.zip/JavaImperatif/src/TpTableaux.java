
public class TpTableaux {

	public static void main(String args[]) {
		int t[] = new int[10];
		for (int i = 0; i < 10; i++) {
			t[i] = (int) (Math.random() * 100);
		}
		
		System.out.println("Avant tri :");
		displayArray(t);
		
		triSelection(t);

		System.out.println("Apr�s tri � bulle :");
		triBulle(t);
		displayArray(t);

		System.out.println("Apr�s tri par s�lection :");
		displayArray(t);
	}
	
	private static void triBulle(int t[]) {
		boolean permutation = true;
	  	int temp;
	  	  	
	  	int maxIndex = t.length - 1;
  	  	while (permutation && maxIndex > 0) {
  	  		permutation = false;
			for(int i = 0; i < t.length - 1; i++) {
				if (t[i] > t[i+1]) {
					temp = t[i];
					t[i] = t[i+1];
					t[i+1] = temp;
					permutation = true;
				}
			}
			maxIndex--;
  	  	}
	}
	
	private static void triSelection(int t[]) {
		int temp;
		
		for (int i = 0; i < t.length - 1; i ++) {
			int minIndex = i;
			for (int j = i; j < t.length; j++) {
				if (t[minIndex] > t[j]) {
					minIndex = j;
				}
			}
			
			if (minIndex != i) {
				temp = t[i];
				t[i] = t[minIndex];
				t[minIndex] = temp;
			}
		}
	}
	
	private static void displayArray(int array[]) {
		for (int i : array) {
			System.out.print(formatteSurNCaracteres(i, 2) + " | ");
		}
		System.out.println();
	}
	
	private static String formatteSurNCaracteres(int entier, int nombreCaracteres) {
		String chaine = "" + entier;
		while (chaine.length() < nombreCaracteres) {
			chaine = "0" + chaine;
		}
		return chaine;
	}
}
