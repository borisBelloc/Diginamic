
/**
 * 
 * @author stazi
 *
 */
public class TpJavaImperatif {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Appeler ici la méthode correspondant au TP.
		// Pensez à renseigner des paramètres valides (Flèche verte > Run configurations
		// > etc.)
		tp0401(args);
	}

	private static void tp01(String[] names) {
		for (int i = 0; i < names.length; i++) {
			System.out.println("Bonjour " + names[i]);
		}
	}

	private static void tp02() {
		// Partie 1
		int integerNumber = 1234;
		float floatNumber = integerNumber;

		System.out.println("Integer number = " + integerNumber);
		System.out.println("Float number = " + floatNumber);

		integerNumber = 123456789;
		floatNumber = integerNumber;

		System.out.println("Integer number = " + integerNumber);
		System.out.println("Float number = " + floatNumber);

		// Partie 2
		System.out.println();
		System.out.println("Partie 2");
		float x = 15f, y = -123f, z = 0f, a = x / z, b = y / z, c = a / b;

		System.out.println("x = " + x);
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
	}

	private static void tp03() {
		byte x = 10;
		x += 1000;
		System.out.println(x);
	}

	private static void tp0401(String args[]) {
		int discountRate;

		float price = Float.parseFloat(args[0]);

		if (price < 1000f) {
			discountRate = 0;
		} else if (price < 2000f) {
			discountRate = 1;
		} else if (price < 5000f) {
			discountRate = 3;
		} else {
			discountRate = 5;
		}

		float discount = price * discountRate / 100;
		float discountedPrice = price * (100 - discountRate) / 100;

		System.out.println("Taux de remise appliqué : " + discountRate + "%");
		System.out.println("Montant de la remise : " + discount + "€");
		System.out.println("Montant après remise : " + discountedPrice + "€");
	}

	private static void tp0402(String args[]) {
		int weight = Integer.parseInt(args[0]);

		String description;
		if (weight < 1) {
			description = "Indéterminé";
		} else {
			switch (weight) {
			case 1:
				description = "Petit";
				break;
			case 2:
				description = "Moyen";
				break;
			default:
				description = "Grand";
				break;
			}
		}

		System.out.println(description);
	}

	private static void tp05(String args[]) {
		int n = Integer.parseInt(args[0]);

		int i = 0;
		while (i < n) {
			System.out.println(i++);
		}
	}

	private static void tp06(String args[]) {
		int n = Integer.parseInt(args[0]);

		long factorielle = 1;
		for (int i = n; i >= 2; i--) {
			factorielle *= i;
		}

		System.out.println(factorielle);
	}

	private static void tp07(String args[]) {
		final int primeNumbersToDisplay = Integer.parseInt(args[0]);
		int primeNumbersDisplayed = 0;

		int currentlyTestedNumber = 2;
		while (primeNumbersDisplayed < primeNumbersToDisplay) {
			int modulo = -1;

			for (int i = 2; i <= Math.sqrt(currentlyTestedNumber) && modulo != 0; i++) {
				modulo = currentlyTestedNumber % i;
			}

			if (modulo != 0) {
				System.out.println(currentlyTestedNumber);
				primeNumbersDisplayed++;
			}

			currentlyTestedNumber++;
		}
	}

	private static void tpMonnaie(String args[]) {
		long price = Long.parseLong(args[0]);
		long remaining = price;

		long count50Bills = remaining / 50;
		remaining %= 50;

		int count20Bills = (int) remaining / 20;
		remaining %= 20;

		int count10Bills = (int) remaining / 10;
		remaining %= 10;

		int count5Bills = (int) remaining / 5;
		remaining %= 5;

		int count2Coins = (int) remaining / 2;
		remaining %= 2;

		int count1Coins = (int) remaining;

		System.out.println("Billets de 50 : " + count50Bills);
		System.out.println("Billets de 20 : " + count20Bills);
		System.out.println("Billets de 10 : " + count10Bills);
		System.out.println("Billets de 5 : " + count5Bills);
		System.out.println("Pi�ces de 2 : " + count2Coins);
		System.out.println("Pi�ces de 1 : " + count1Coins);
	}

	private static void tpMonnaieArray(String args[]) {
		long price = Long.parseLong(args[0]);
		long remaining = price;

		int billsValues[] = { 50, 20, 10, 5, 2, 1 };

		for (int i = 0; i < billsValues.length; i++) {
			int billAmount = (int) (remaining / billsValues[i]);
			remaining %= billsValues[i];
			System.out.println("Billets de " + billsValues[i] + " : " + billAmount);
		}
	}
}
